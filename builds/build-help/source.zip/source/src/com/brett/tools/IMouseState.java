package com.brett.tools;

public interface IMouseState {
	
	public void onMousePressed(int button);
	
	public void onMouseReleased(int button);
	
}
