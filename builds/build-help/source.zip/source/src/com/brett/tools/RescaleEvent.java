package com.brett.tools;

/**
* @author Brett
* @date Jun. 24, 2020
*/

public interface RescaleEvent {
	
	public void rescale();
	
}
