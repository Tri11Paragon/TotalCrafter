package com.brett.tools;

/**
* @author Brett
* @date Jul. 1, 2020
*/

public interface NdLoopAll<K, V> {
	public void loopd(NdHashMap<K, V> dt, K k1, K k2, K k3, V v1);
}
