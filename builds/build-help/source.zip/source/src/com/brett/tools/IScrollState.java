package com.brett.tools;

/**
* @author Brett
* @date 21-Aug-2020
*/

public interface IScrollState {
	
	public void scroll(int dir);
	
}
