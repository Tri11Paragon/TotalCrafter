package com.brett.tools;

public interface IKeyState {
	
	public void onKeyPressed(int keys);
	
	public void onKeyReleased(int keys);
	
}
