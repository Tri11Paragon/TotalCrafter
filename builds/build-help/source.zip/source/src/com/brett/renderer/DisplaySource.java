package com.brett.renderer;

/**
*
* @author brett
* @date Mar. 9, 2020
* This is used to change from main menu to the actual game.
*/

public interface DisplaySource {
	
	public void render();
	
}
