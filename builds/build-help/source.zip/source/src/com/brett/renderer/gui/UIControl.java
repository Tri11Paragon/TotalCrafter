package com.brett.renderer.gui;

/**
*
* @author brett
* just an event that gets called when something happens to the UI
* normally this is called when buttons get pressed
*/

public interface UIControl {
	
	public void event(String data);
	
}
