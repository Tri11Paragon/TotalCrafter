package com.brett.voxel.renderer;

/**
*
* @author brett
* @date May 15, 2020
*/

public enum RENDERMODE {
	
	SOLID, TRANSPARENT, TRANSLUCENT, SPECIAL;
	
}
