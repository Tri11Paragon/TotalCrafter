package com.brett.voxel.inventory;

/**
*
* @author brett
* @date May 13, 2020
* interface for changes in slot
*/

public interface SlotChange {
	
	public void onChange(Slot s);
	
}
