package com.brett.voxel.renderer;

/**
*
* @author brett
* @date May 25, 2020
* Solid or not solid
*/

public enum COLLISIONTYPE {
	SOLID, NOT
}
