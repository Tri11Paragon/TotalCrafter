package com.brett.voxel.tools;

/**
*
* @author brett
* @date Mar. 15, 2020
*/

public interface IEventListener {
	
	public void event();
	
}
