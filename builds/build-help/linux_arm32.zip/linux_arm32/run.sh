java -jar help_linux.jar
