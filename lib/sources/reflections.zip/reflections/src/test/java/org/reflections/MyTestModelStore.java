//generated using Reflections JavaCodeSerializer [Tue Nov 11 12:45:43 CET 2014]
package org.reflections;

public interface MyTestModelStore {

	public interface org {
		public interface reflections {
			public interface TestModel$AC1 {
				public interface annotations {
					public interface java_lang_annotation_Inherited {}
					public interface java_lang_annotation_Retention {}
				}
			}
			public interface TestModel$AC1n {
				public interface annotations {
					public interface java_lang_annotation_Retention {}
				}
			}
			public interface TestModel$AC2 {
				public interface methods {
					public interface value {}
				}
				public interface annotations {
					public interface java_lang_annotation_Retention {}
				}
			}
			public interface TestModel$AC3 {
				public interface annotations {
					public interface java_lang_annotation_Retention {}
					public interface org_reflections_TestModel$AC2 {}
				}
			}
			public interface TestModel$AF1 {
				public interface methods {
					public interface value {}
				}
				public interface annotations {
					public interface java_lang_annotation_Retention {}
				}
			}
			public interface TestModel$AI1 {
				public interface annotations {
					public interface org_reflections_TestModel$MAI1 {}
					public interface java_lang_annotation_Retention {}
				}
			}
			public interface TestModel$AI2 {
				public interface annotations {
					public interface java_lang_annotation_Inherited {}
					public interface java_lang_annotation_Retention {}
				}
			}
			public interface TestModel$AM1 {
				public interface methods {
					public interface value {}
				}
				public interface annotations {
					public interface java_lang_annotation_Retention {}
				}
			}
			public interface TestModel$C1 {
				public interface annotations {
					public interface org_reflections_TestModel$AC1n {}
					public interface org_reflections_TestModel$AC1 {}
				}
			}
			public interface TestModel$C2 {
				public interface annotations {
					public interface org_reflections_TestModel$AC2 {}
				}
			}
			public interface TestModel$C3 {
				public interface annotations {
					public interface org_reflections_TestModel$AC2 {}
				}
			}
			public interface TestModel$C4 {
				public interface fields {
					public interface f3 {}
					public interface f1 {}
					public interface f2 {}
				}
				public interface methods {
					public interface c2toC3 {}
					public interface m1_int__java_lang_String$$ {}
					public interface m1_int$$$$__java_lang_String$$$$ {}
					public interface m1 {}
					public interface m3 {}
					public interface m4 {}
					public interface add {}
				}
			}
			public interface TestModel$C5 {
			}
			public interface TestModel$C6 {
			}
			public interface TestModel$C7 {
				public interface annotations {
					public interface org_reflections_TestModel$AC3 {}
				}
			}
			public interface TestModel$I1 {
				public interface annotations {
					public interface org_reflections_TestModel$AI1 {}
				}
			}
			public interface TestModel$I2 {
				public interface annotations {
					public interface org_reflections_TestModel$AI2 {}
				}
			}
			public interface TestModel$I3 {
				public interface annotations {
					public interface org_reflections_TestModel$AC2 {}
				}
			}
			public interface TestModel$MAI1 {
				public interface annotations {
					public interface java_lang_annotation_Inherited {}
					public interface java_lang_annotation_Retention {}
				}
			}
			public interface TestModel$Usage {
			}
			public interface TestModel$Usage$C1 {
				public interface fields {
					public interface c2 {}
				}
				public interface methods {
					public interface method_java_lang_String {}
					public interface method {}
				}
			}
			public interface TestModel$Usage$C2 {
				public interface fields {
					public interface c1 {}
				}
				public interface methods {
					public interface method {}
				}
			}
		}
	}
}
