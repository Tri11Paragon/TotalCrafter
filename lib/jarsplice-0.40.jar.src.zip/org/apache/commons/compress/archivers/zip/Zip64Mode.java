/*    */ package org.apache.commons.compress.archivers.zip;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Zip64Mode
/*    */ {
/* 29 */   Always,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   Never,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   AsNeeded;
/*    */ }


/* Location:              /home/brett/Documents/Java/TotalCrafter/lib/jarsplice-0.40.jar!/org/apache/commons/compress/archivers/zip/Zip64Mode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */