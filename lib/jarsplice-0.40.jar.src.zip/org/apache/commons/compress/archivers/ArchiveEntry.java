package org.apache.commons.compress.archivers;

import java.util.Date;

public interface ArchiveEntry {
  public static final long SIZE_UNKNOWN = -1L;
  
  String getName();
  
  long getSize();
  
  boolean isDirectory();
  
  Date getLastModifiedDate();
}


/* Location:              /home/brett/Documents/Java/TotalCrafter/lib/jarsplice-0.40.jar!/org/apache/commons/compress/archivers/ArchiveEntry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */