/*    */ package org.ninjacave.jarsplice;
/*    */ 
/*    */ import org.ninjacave.jarsplice.gui.JarSpliceFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarSplice
/*    */ {
/*    */   public static void main(String[] args) {
/* 39 */     JarSpliceFrame gui = new JarSpliceFrame();
/*    */   }
/*    */ }


/* Location:              /home/brett/Documents/Java/TotalCrafter/lib/jarsplice-0.40.jar!/org/ninjacave/jarsplice/JarSplice.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */